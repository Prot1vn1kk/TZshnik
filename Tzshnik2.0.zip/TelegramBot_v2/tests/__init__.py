"""
Тесты проекта "ТЗшник v2.0".

Содержит:
- test_ai_providers.py - тесты AI провайдеров
- test_generator.py - тесты генератора ТЗ
- test_validator.py - тесты валидатора
"""
