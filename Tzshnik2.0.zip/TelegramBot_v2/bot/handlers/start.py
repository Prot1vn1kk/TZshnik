"""
Обработчики стартовых команд.

Содержит:
- /start - приветствие и главное меню
- /help - справка
- Кнопки главного меню (Баланс, История)
"""

from aiogram import Router, F
from aiogram.filters import Command, CommandStart
from aiogram.types import Message, CallbackQuery, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.fsm.context import FSMContext
import structlog

from database import (
    get_user_stats,
    get_user_generations,
    get_generation_by_id,
    create_idea,
    is_unlimited_active,
)
from database.models import User
from bot.keyboards import (
    get_main_menu_keyboard,
    get_balance_keyboard,
    get_start_inline_keyboard,
    get_history_keyboard,
    get_tz_detail_keyboard,
    get_back_keyboard,
)
from bot.states import GenerationStates, IdeaStates


logger = structlog.get_logger()
router = Router(name="start")


def get_balance_display(user: User) -> str:
    """Отображение баланса с учётом безлимита."""
    return "∞" if is_unlimited_active(user) else str(user.balance)


# ============================================================
# ТЕКСТЫ СООБЩЕНИЙ
# ============================================================

START_MESSAGE = """
🎯 <b>ТЗшник</b> — твой AI-помощник для маркетплейсов

Создаю профессиональные технические задания для инфографики карточек товаров на Wildberries и Ozon.

━━━━━━━━━━━━━━━━━━━━━

🔥 <b>Что я умею:</b>
• Анализирую фото товара с помощью AI
• Генерирую детальные ТЗ для дизайнера
• Готовые тексты, цвета, структура слайдов
• Экспорт в PDF для передачи исполнителю

⏱ <b>Как это работает:</b>
1. Отправь фото товара (1-5 шт.)
2. Выбери категорию
3. Получи готовое ТЗ за 30-60 сек!

━━━━━━━━━━━━━━━━━━━━━

💰 <b>Твой баланс: {balance} генераций</b>

👇 Нажми «🚀 Создать ТЗ» чтобы начать!
"""

HELP_MESSAGE = """
📖 <b>Справка по ТЗшнику</b>

<b>Команды:</b>
/start — Главное меню
/help — Эта справка

<b>Как создать ТЗ:</b>
1. Нажми «🚀 Создать ТЗ»
2. Отправь от 1 до 5 фото товара
3. Выбери категорию
4. Дождись генерации (30-60 сек)
5. Скачай PDF или перегенерируй

<b>Баланс:</b>
• Каждая генерация = 1 кредит
• Пополнить: нажми «💰 Баланс»
• Новые пользователи: {free_credits} бесплатных генераций

<b>Советы для лучшего результата:</b>
📷 Используй качественные фото
📷 Покажи товар с разных сторон
📷 Добавь фото упаковки

Вопросы? Напиши @TZshnik_support_bot
"""

BALANCE_MESSAGE = """
💰 <b>Твой баланс: {balance} генераций</b>

📊 <b>Статистика:</b>
• Всего создано ТЗ: {total_generations}
• Успешных: {successful}

{status_text}

━━━━━━━━━━━━━━━━━━━━━
"""

MENU_MESSAGE = """
📖 <b>Главное меню ТЗшника</b>

━━━━━━━━━━━━━━━━━━━━━

🚀 <b>Создать ТЗ</b> — создать новое техническое задание

💰 <b>Баланс</b> — проверить количество оставшихся генераций и пополнить

📋 <b>Мои ТЗ</b> — история твоих генераций

📝 <b>Примеры</b> — посмотреть примеры готовых ТЗ

━━━━━━━━━━━━━━━━━━━━━

💳 <b>Тарифы:</b>
🎁 Пробный — 3 ТЗ за 79₽
🔹 Старт — 5 ТЗ за 129₽
📦 Базовый — 10 ТЗ за 229₽
⭐ Оптимальный — 25 ТЗ за 449₽ 🔥
🚀 Профи — 50 ТЗ за 749₽
💼 Бизнес — 100 ТЗ за 1 290₽ 💎
🏢 Корпоративный — 250 ТЗ за 2 790₽

━━━━━━━━━━━━━━━━━━━━━

👑 <b>БЕЗЛИМИТ</b> — 1 790₽/месяц
    Неограниченные генерации на 30 дней!

━━━━━━━━━━━━━━━━━━━━━

❓ Поддержка: @TZshnik_support_bot
"""

EXAMPLES_MESSAGE = """
📝 <b>Примеры готовых ТЗ</b>

Выбери категорию, чтобы увидеть качественный пример технического задания для инфографики:

━━━━━━━━━━━━━━━━━━━━━

👕 <b>Одежда и аксессуары</b>
Платья, куртки, обувь, сумки

📱 <b>Электроника</b>
Наушники, смартфоны, аксессуары

💄 <b>Косметика и уход</b>
Кремы, сыворотки, декоративная косметика

🏠 <b>Товары для дома</b>
Текстиль, декор, кухонные принадлежности

👶 <b>Детские товары</b>
Игрушки, одежда, развивающие товары

⚽ <b>Спорт и отдых</b>
Спортивная одежда, инвентарь, туризм

━━━━━━━━━━━━━━━━━━━━━

👇 Выбери категорию для просмотра примера:
"""


# ============================================================
# ДЕТАЛЬНЫЕ ПРИМЕРЫ ПО КАТЕГОРИЯМ
# ============================================================

EXAMPLE_CLOTHES = """
👕 <b>ПРИМЕР ТЗ: Одежда и аксессуары</b>

━━━━━━━━━━━━━━━━━━━━━

📦 <b>ТОВАР</b>
Летнее платье макси с цветочным принтом
Материал: вискоза 95%, эластан 5%
Размеры: S, M, L, XL, XXL

━━━━━━━━━━━━━━━━━━━━━

👥 <b>ЦЕЛЕВАЯ АУДИТОРИЯ</b>
• Женщины 25-45 лет
• Средний+ доход
• Ценят комфорт и стиль
• Покупают для отпуска/прогулок/свиданий

━━━━━━━━━━━━━━━━━━━━━

🎨 <b>ВИЗУАЛЬНАЯ КОНЦЕПЦИЯ</b>
Стиль: нежный романтик
Настроение: лёгкость, женственность, лето
Цветовая палитра:
• Основной: #FFB6C1 (нежно-розовый)
• Акцент: #228B22 (зелёный лист)
• Фон: #FFF5EE (кремовый)
• Текст: #2F4F4F (тёмно-серый)

━━━━━━━━━━━━━━━━━━━━━

📸 <b>ГЛАВНОЕ ФОТО (Слайд 1)</b>
• Модель в платье в полный рост
• Фон: нейтральный светлый градиент
• Освещение: мягкое, естественное
• Поза: лёгкая, непринуждённая

━━━━━━━━━━━━━━━━━━━━━

📊 <b>ИНФОГРАФИКА (Слайды 2-7)</b>

<b>Слайд 2 — УТП и преимущества</b>
Заголовок: "Твоё идеальное летнее платье"
• Иконка ткани + "Дышащая вискоза"
• Иконка длины + "Элегантная макси длина"
• Иконка размера + "Размеры S-XXL"

<b>Слайд 3 — Детали и качество</b>
• Крупный план принта
• Показ швов и качества пошива
• Фурнитура (если есть)

<b>Слайд 4 — Размерная сетка</b>
• Наглядная таблица размеров
• Параметры: грудь, талия, бёдра, длина
• Рекомендации по выбору размера

<b>Слайд 5 — Образы и сочетания</b>
• 3 варианта образа с платьем
• Подходящая обувь и аксессуары
• Для разных случаев

<b>Слайд 6 — Уход за изделием</b>
• Иконки стирки, глажки
• Простые инструкции
• Срок службы

<b>Слайд 7 — Доставка и гарантии</b>
• Сроки доставки
• Бесплатный возврат
• Отзывы покупателей

━━━━━━━━━━━━━━━━━━━━━

📝 <b>ГОТОВЫЕ ТЕКСТЫ</b>

Заголовок: "Летнее платье макси — Ваш стиль этого сезона"

УТП: 
• "Дышит в жару — 95% натуральная вискоза"
• "Стройнит силуэт — приталенный крой"
• "Универсальный принт — от пляжа до ресторана"

Призыв: "Добавь в корзину и стань самой стильной этим летом!"

━━━━━━━━━━━━━━━━━━━━━

💡 <b>РЕКОМЕНДАЦИИ ДИЗАЙНЕРУ</b>
• Использовать нежные пастельные тона
• Добавить лёгкие цветочные элементы декора
• Шрифты: современные с засечками для заголовков
• Много воздуха в композиции

━━━━━━━━━━━━━━━━━━━━━

🔬 <b>A/B ТЕСТ</b>
Вариант А: Фото модели на нейтральном фоне
Вариант Б: Фото модели на природе (парк/сад)

━━━━━━━━━━━━━━━━━━━━━

🚀 <i>Хочешь такое же ТЗ для своего товара?</i>
"""


EXAMPLE_ELECTRONICS = """
📱 <b>ПРИМЕР ТЗ: Электроника</b>

━━━━━━━━━━━━━━━━━━━━━

📦 <b>ТОВАР</b>
Беспроводные TWS наушники с шумоподавлением
Время работы: 8ч (кейс: 32ч)
Bluetooth 5.3, IPX4 защита

━━━━━━━━━━━━━━━━━━━━━

👥 <b>ЦЕЛЕВАЯ АУДИТОРИЯ</b>
• Мужчины и женщины 18-45 лет
• Активный образ жизни
• Ценят качество звука
• Используют для спорта, работы, путешествий

━━━━━━━━━━━━━━━━━━━━━

🎨 <b>ВИЗУАЛЬНАЯ КОНЦЕПЦИЯ</b>
Стиль: технологичный минимализм
Настроение: премиум, инновации, надёжность
Цветовая палитра:
• Основной: #1A1A1A (глубокий чёрный)
• Акцент: #00D4FF (неоновый голубой)
• Фон: #F5F5F7 (светло-серый)
• Текст: #FFFFFF (белый) / #333333 (тёмный)

━━━━━━━━━━━━━━━━━━━━━

📸 <b>ГЛАВНОЕ ФОТО (Слайд 1)</b>
• Наушники + кейс на тёмном градиенте
• Эффект свечения/подсветки
• 3D эффект "парящего" товара
• Акцент на премиальном дизайне

━━━━━━━━━━━━━━━━━━━━━

📊 <b>ИНФОГРАФИКА (Слайды 2-8)</b>

<b>Слайд 2 — Ключевые характеристики</b>
Заголовок: "Звук нового поколения"
• Иконка батареи + "32 часа автономности"
• Иконка ANC + "Активное шумоподавление"
• Иконка Bluetooth + "Bluetooth 5.3"

<b>Слайд 3 — Качество звука</b>
• Визуализация драйверов
• Частотный диапазон
• Поддерживаемые кодеки

<b>Слайд 4 — Шумоподавление</b>
• Сравнение: до/после
• Режимы: ANC / Прозрачность
• Инфографика работы микрофонов

<b>Слайд 5 — Комфорт и эргономика</b>
• Вес: 5г каждый наушник
• 3 размера амбушюр в комплекте
• Показ в ухе

<b>Слайд 6 — Защита и надёжность</b>
• IPX4 — защита от пота и брызг
• Прочный кейс
• Совместимость: iOS/Android

<b>Слайд 7 — Комплектация</b>
• Наушники + кейс
• 3 пары амбушюр
• USB-C кабель
• Инструкция

<b>Слайд 8 — Гарантия и поддержка</b>
• Официальная гарантия 1 год
• Быстрая доставка
• Бесплатный возврат 14 дней

━━━━━━━━━━━━━━━━━━━━━

📝 <b>ГОТОВЫЕ ТЕКСТЫ</b>

Заголовок: "TWS наушники с ANC — Погрузись в чистый звук"

УТП:
• "Шумоподавление -40дБ — работай в тишине"
• "32 часа без зарядки — на всю неделю"
• "Bluetooth 5.3 — стабильное соединение"

Призыв: "Заказывай сейчас и получи чехол в подарок!"

━━━━━━━━━━━━━━━━━━━━━

💡 <b>РЕКОМЕНДАЦИИ ДИЗАЙНЕРУ</b>
• Тёмный фон с неоновыми акцентами
• Использовать 3D-визуализацию
• Технические иконки в едином стиле
• Минимум текста, максимум визуала

━━━━━━━━━━━━━━━━━━━━━

🔬 <b>A/B ТЕСТ</b>
Вариант А: Наушники на тёмном фоне с подсветкой
Вариант Б: Наушники в использовании (на модели)

━━━━━━━━━━━━━━━━━━━━━

🚀 <i>Хочешь такое же ТЗ для своего товара?</i>
"""


EXAMPLE_COSMETICS = """
💄 <b>ПРИМЕР ТЗ: Косметика и уход</b>

━━━━━━━━━━━━━━━━━━━━━

📦 <b>ТОВАР</b>
Увлажняющий крем для лица с гиалуроновой кислотой
Объём: 50 мл
Состав: гиалуроновая кислота, ниацинамид, масло жожоба

━━━━━━━━━━━━━━━━━━━━━

👥 <b>ЦЕЛЕВАЯ АУДИТОРИЯ</b>
• Женщины 25-50 лет
• Заботятся о состоянии кожи
• Предпочитают качественную косметику
• Знают о пользе гиалуроновой кислоты

━━━━━━━━━━━━━━━━━━━━━

🎨 <b>ВИЗУАЛЬНАЯ КОНЦЕПЦИЯ</b>
Стиль: чистота и натуральность
Настроение: свежесть, молодость, уход
Цветовая палитра:
• Основной: #E8F4F8 (нежно-голубой)
• Акцент: #4ECDC4 (бирюзовый)
• Фон: #FFFFFF (белый)
• Текст: #2C3E50 (тёмно-синий)

━━━━━━━━━━━━━━━━━━━━━

📸 <b>ГЛАВНОЕ ФОТО (Слайд 1)</b>
• Банка крема на светлом фоне
• Капли воды / росы рядом
• Листочки алоэ или цветы
• Чистый, минималистичный стиль

━━━━━━━━━━━━━━━━━━━━━

📊 <b>ИНФОГРАФИКА (Слайды 2-7)</b>

<b>Слайд 2 — Ключевые ингредиенты</b>
Заголовок: "Сила увлажнения в каждой капле"
• Молекула + "Гиалуроновая кислота"
• Капля + "Ниацинамид 5%"
• Орех + "Масло жожоба"

<b>Слайд 3 — Результат применения</b>
• До/После (реалистично)
• Временная шкала: 1 день / 2 недели / месяц
• Процент улучшения увлажнённости

<b>Слайд 4 — Состав и безопасность</b>
• Без парабенов
• Без силиконов
• Гипоаллергенно
• Дерматологически протестировано

<b>Слайд 5 — Способ применения</b>
• Пошаговая инструкция с иконками
• Утро и вечер
• Количество продукта

<b>Слайд 6 — Для какого типа кожи</b>
• Сухая ✓
• Нормальная ✓
• Комбинированная ✓
• Чувствительная ✓

<b>Слайд 7 — Отзывы и гарантии</b>
• Цитаты реальных покупателей
• Рейтинг 4.8 из 5
• Гарантия качества

━━━━━━━━━━━━━━━━━━━━━

📝 <b>ГОТОВЫЕ ТЕКСТЫ</b>

Заголовок: "Увлажняющий крем с гиалуроновой кислотой — Молодость кожи"

УТП:
• "48 часов глубокого увлажнения"
• "Видимый результат за 14 дней"
• "Натуральный состав без парабенов"

Призыв: "Попробуй и почувствуй разницу уже завтра!"

━━━━━━━━━━━━━━━━━━━━━

💡 <b>РЕКОМЕНДАЦИИ ДИЗАЙНЕРУ</b>
• Светлые, чистые тона
• Элементы воды, капель, свежести
• Шрифты: тонкие, элегантные
• Акцент на натуральности

━━━━━━━━━━━━━━━━━━━━━

🔬 <b>A/B ТЕСТ</b>
Вариант А: Минималистичный продуктовый фон
Вариант Б: Крем в руках модели / на коже

━━━━━━━━━━━━━━━━━━━━━

🚀 <i>Хочешь такое же ТЗ для своего товара?</i>
"""


EXAMPLE_HOME = """
🏠 <b>ПРИМЕР ТЗ: Товары для дома</b>

━━━━━━━━━━━━━━━━━━━━━

📦 <b>ТОВАР</b>
Плед флисовый с рукавами
Размер: 150x200 см
Материал: микрофлис 100%

━━━━━━━━━━━━━━━━━━━━━

👥 <b>ЦЕЛЕВАЯ АУДИТОРИЯ</b>
• Женщины и мужчины 20-55 лет
• Ценят домашний уют
• Покупают для себя или в подарок
• Любят комфортный отдых

━━━━━━━━━━━━━━━━━━━━━

🎨 <b>ВИЗУАЛЬНАЯ КОНЦЕПЦИЯ</b>
Стиль: тёплый хюгге
Настроение: уют, комфорт, тепло
Цветовая палитра:
• Основной: #8B4513 (тёплый коричневый)
• Акцент: #F4A460 (песочный)
• Фон: #FAF0E6 (льняной)
• Текст: #3E2723 (тёмно-коричневый)

━━━━━━━━━━━━━━━━━━━━━

📸 <b>ГЛАВНОЕ ФОТО (Слайд 1)</b>
• Человек в пледе на диване
• Чашка с горячим напитком рядом
• Тёплое освещение
• Уютная домашняя атмосфера

━━━━━━━━━━━━━━━━━━━━━

📊 <b>ИНФОГРАФИКА (Слайды 2-6)</b>

<b>Слайд 2 — Преимущества</b>
Заголовок: "Твой идеальный вечер дома"
• Иконка термометра + "Сохраняет тепло"
• Иконка рук + "Руки свободны"
• Иконка размера + "150x200 см"

<b>Слайд 3 — Материал и качество</b>
• Крупный план текстуры
• 100% микрофлис
• Не скатывается после стирок

<b>Слайд 4 — Использование</b>
• На диване / в кресле
• За компьютером
• Чтение книги
• Просмотр ТВ

<b>Слайд 5 — Уход</b>
• Машинная стирка 30°
• Быстро сохнет
• Не требует глажки

<b>Слайд 6 — Подарочная идея</b>
• Красивая упаковка
• Идеально на Новый год
• Подходит всем

━━━━━━━━━━━━━━━━━━━━━

📝 <b>ГОТОВЫЕ ТЕКСТЫ</b>

Заголовок: "Плед с рукавами — Окутай себя уютом"

УТП:
• "Руки свободны — читай, пей чай, работай"
• "Микрофлис — мягкость как у облака"
• "Стирается легко — сохраняет вид"

Призыв: "Закажи сейчас и наслаждайся уютом уже завтра!"

━━━━━━━━━━━━━━━━━━━━━

💡 <b>РЕКОМЕНДАЦИИ ДИЗАЙНЕРУ</b>
• Тёплые осенне-зимние цвета
• Элементы уюта: свечи, книги, чашки
• Мягкое освещение на фото
• Акцент на текстуре материала

━━━━━━━━━━━━━━━━━━━━━

🔬 <b>A/B ТЕСТ</b>
Вариант А: Модель в пледе дома
Вариант Б: Плед сложенный + элементы декора

━━━━━━━━━━━━━━━━━━━━━

🚀 <i>Хочешь такое же ТЗ для своего товара?</i>
"""


EXAMPLE_KIDS = """
👶 <b>ПРИМЕР ТЗ: Детские товары</b>

━━━━━━━━━━━━━━━━━━━━━

📦 <b>ТОВАР</b>
Развивающий конструктор для детей 3-7 лет
Количество деталей: 150 шт
Материал: ABS пластик

━━━━━━━━━━━━━━━━━━━━━

👥 <b>ЦЕЛЕВАЯ АУДИТОРИЯ</b>
• Родители детей 3-7 лет
• Бабушки и дедушки (покупка в подарок)
• Заботятся о развитии ребёнка
• Ищут безопасные игрушки

━━━━━━━━━━━━━━━━━━━━━

🎨 <b>ВИЗУАЛЬНАЯ КОНЦЕПЦИЯ</b>
Стиль: яркий и весёлый
Настроение: радость, игра, развитие
Цветовая палитра:
• Основной: #FF6B6B (коралловый)
• Акцент: #4ECDC4 (бирюзовый)
• Дополнительный: #FFE66D (жёлтый)
• Фон: #FFFFFF (белый)

━━━━━━━━━━━━━━━━━━━━━

📸 <b>ГЛАВНОЕ ФОТО (Слайд 1)</b>
• Счастливый ребёнок играет с конструктором
• Яркие цвета и эмоции
• Светлый фон
• Видны собранные фигуры

━━━━━━━━━━━━━━━━━━━━━

📊 <b>ИНФОГРАФИКА (Слайды 2-7)</b>

<b>Слайд 2 — Развивающие навыки</b>
Заголовок: "Играй и развивайся!"
• Мозг + "Логическое мышление"
• Рука + "Мелкая моторика"
• Творчество + "Воображение"

<b>Слайд 3 — Безопасность</b>
• Сертификат безопасности
• Без острых углов
• Экологичный ABS пластик
• Без запаха

<b>Слайд 4 — Что можно собрать</b>
• 20+ готовых моделей
• Домики, машинки, животные
• Инструкция с картинками

<b>Слайд 5 — Комплектация</b>
• 150 деталей
• Удобный контейнер для хранения
• Книжка-инструкция

<b>Слайд 6 — Возраст и совместимость</b>
• Подходит для 3-7 лет
• Совместим с другими конструкторами
• Можно докупить дополнительные наборы

<b>Слайд 7 — Идеальный подарок</b>
• На день рождения
• На Новый год
• Просто так
• Упаковка готова для подарка

━━━━━━━━━━━━━━━━━━━━━

📝 <b>ГОТОВЫЕ ТЕКСТЫ</b>

Заголовок: "Развивающий конструктор — 150 деталей счастья"

УТП:
• "Развивает логику и моторику — рекомендуют педагоги"
• "Безопасный ABS пластик — сертифицировано"
• "150 деталей — часы увлекательной игры"

Призыв: "Подари ребёнку развитие через игру!"

━━━━━━━━━━━━━━━━━━━━━

💡 <b>РЕКОМЕНДАЦИИ ДИЗАЙНЕРУ</b>
• Яркие, сочные цвета
• Фото счастливых детей
• Крупные иконки безопасности
• Шрифты: округлые, дружелюбные

━━━━━━━━━━━━━━━━━━━━━

🔬 <b>A/B ТЕСТ</b>
Вариант А: Ребёнок играет с конструктором
Вариант Б: Готовые собранные модели

━━━━━━━━━━━━━━━━━━━━━

🚀 <i>Хочешь такое же ТЗ для своего товара?</i>
"""


EXAMPLE_SPORTS = """
⚽ <b>ПРИМЕР ТЗ: Спорт и отдых</b>

━━━━━━━━━━━━━━━━━━━━━

📦 <b>ТОВАР</b>
Фитнес-резинки для тренировок (набор 5 шт)
Сопротивление: от 2 до 22 кг
Материал: 100% латекс

━━━━━━━━━━━━━━━━━━━━━

👥 <b>ЦЕЛЕВАЯ АУДИТОРИЯ</b>
• Женщины 20-45 лет
• Занимаются фитнесом дома
• Следят за фигурой
• Ищут компактное оборудование

━━━━━━━━━━━━━━━━━━━━━

🎨 <b>ВИЗУАЛЬНАЯ КОНЦЕПЦИЯ</b>
Стиль: энергичный и мотивирующий
Настроение: сила, здоровье, энергия
Цветовая палитра:
• Основной: #FF4757 (энергичный красный)
• Акцент: #2ED573 (зелёный)
• Фон: #F1F2F6 (светло-серый)
• Текст: #2F3542 (тёмно-серый)

━━━━━━━━━━━━━━━━━━━━━

📸 <b>ГЛАВНОЕ ФОТО (Слайд 1)</b>
• Девушка тренируется с резинкой
• Спортивная форма
• Динамичная поза
• Светлый фон

━━━━━━━━━━━━━━━━━━━━━

📊 <b>ИНФОГРАФИКА (Слайды 2-7)</b>

<b>Слайд 2 — Преимущества набора</b>
Заголовок: "Твой домашний спортзал в кармане"
• 5 резинок + "5 уровней нагрузки"
• Сумка + "Чехол для хранения"
• Гантеля + "Заменяет тренажёры"

<b>Слайд 3 — Уровни сопротивления</b>
• Жёлтая: 2-4 кг (разминка)
• Зелёная: 4-8 кг (лёгкая)
• Красная: 8-14 кг (средняя)
• Синяя: 14-18 кг (сильная)
• Чёрная: 18-22 кг (максимум)

<b>Слайд 4 — Упражнения</b>
• Ноги и ягодицы
• Руки и плечи
• Пресс
• Растяжка
• 30+ упражнений

<b>Слайд 5 — Качество материала</b>
• 100% натуральный латекс
• Не рвутся
• Не теряют упругость
• Гипоаллергенные

<b>Слайд 6 — Комплектация</b>
• 5 резинок разной нагрузки
• Чехол-мешок
• PDF с упражнениями (QR-код)

<b>Слайд 7 — Результаты</b>
• Фото до/после (реальные)
• Отзывы покупателей
• Гарантия качества

━━━━━━━━━━━━━━━━━━━━━

📝 <b>ГОТОВЫЕ ТЕКСТЫ</b>

Заголовок: "Фитнес-резинки — Идеальное тело за 20 минут в день"

УТП:
• "5 уровней нагрузки — для любой подготовки"
• "Компактный набор — тренируйся где угодно"
• "100% латекс — служат годами"

Призыв: "Начни путь к идеальному телу уже сегодня!"

━━━━━━━━━━━━━━━━━━━━━

💡 <b>РЕКОМЕНДАЦИИ ДИЗАЙНЕРУ</b>
• Энергичные, яркие цвета
• Динамичные фото с тренировкой
• Показать разные цвета резинок
• Мотивационные элементы

━━━━━━━━━━━━━━━━━━━━━

🔬 <b>A/B ТЕСТ</b>
Вариант А: Модель тренируется с резинкой
Вариант Б: Набор резинок + схема упражнений

━━━━━━━━━━━━━━━━━━━━━

🚀 <i>Хочешь такое же ТЗ для своего товара?</i>
"""


# Словарь примеров по категориям
EXAMPLES_BY_CATEGORY = {
    "clothes": EXAMPLE_CLOTHES,
    "electronics": EXAMPLE_ELECTRONICS,
    "cosmetics": EXAMPLE_COSMETICS,
    "home": EXAMPLE_HOME,
    "kids": EXAMPLE_KIDS,
    "sports": EXAMPLE_SPORTS,
}


# ============================================================
# ОБРАБОТЧИКИ КОМАНД
# ============================================================

@router.message(CommandStart())
async def cmd_start(
    message: Message,
    user: User,
    state: FSMContext,
) -> None:
    """
    Обработчик команды /start.
    
    Показывает приветствие и главное меню.
    Сбрасывает состояние FSM.
    """
    # Сбрасываем состояние на случай если пользователь был в процессе
    await state.clear()
    
    # Отправляем стартовое сообщение с inline клавиатурой
    await message.answer(
        START_MESSAGE.format(balance=get_balance_display(user)),
    )
    
    # Отправляем дополнительное сообщение с inline кнопками для быстрого старта
    await message.answer(
        "👇 <b>Быстрые действия:</b>",
        reply_markup=get_start_inline_keyboard(),
    )
    
    logger.info(
        "User started bot",
        telegram_id=message.from_user.id,
        balance=get_balance_display(user),
    )


@router.message(Command("help"))
async def cmd_help(message: Message, user: User) -> None:
    """Обработчик команды /help."""
    from database.admin_crud import get_bot_setting
    
    free_credits = await get_bot_setting("free_credits", "1")
    
    await message.answer(
        HELP_MESSAGE.format(free_credits=free_credits),
        reply_markup=get_main_menu_keyboard(),
    )


@router.message(Command("create"))
async def cmd_create(
    message: Message,
    user: User,
    state: FSMContext,
) -> None:
    """Команда /create - начать создание ТЗ."""
    if user.balance <= 0 and not is_unlimited_active(user):
        await message.answer(
            "❌ <b>У тебя закончились кредиты!</b>\n\n"
            "Нажми «💰 Баланс» или /buy для пополнения.",
            reply_markup=get_main_menu_keyboard(),
        )
        return
    
    await state.set_state(GenerationStates.waiting_photo)
    await state.update_data(photos=[])
    
    await message.answer(
        "📷 <b>Отправь фото товара</b>\n\n"
        "Можно отправить от 1 до 5 фотографий.\n"
        "Чем больше фото с разных ракурсов — тем лучше результат!\n\n"
        "💡 Совет: добавь фото упаковки и деталей товара",
    )
    
    logger.info("User started generation via /create", telegram_id=message.from_user.id)


@router.message(Command("balance"))
async def cmd_balance(message: Message, user: User) -> None:
    """Команда /balance - показать баланс."""
    telegram_id = message.from_user.id if message.from_user else 0
    stats = await get_user_stats(telegram_id)

    if is_unlimited_active(user):
        status_text = "👑 Безлимит активен"
    elif user.balance > 5:
        status_text = "✅ Достаточно кредитов для работы"
    elif user.balance > 0:
        status_text = "⚠️ Кредиты заканчиваются, пополните баланс"
    else:
        status_text = "❌ Кредиты закончились! Пополните баланс"

    total = stats.get("generations_count", 0)

    text = BALANCE_MESSAGE.format(
        balance=get_balance_display(user),
        total_generations=total,
        successful=total,
        status_text=status_text,
    )

    await message.answer(text, reply_markup=get_balance_keyboard())


@router.message(Command("buy"))
async def cmd_buy(message: Message, user: User) -> None:
    """Команда /buy - купить кредиты."""
    from bot.keyboards import get_packages_keyboard

    await message.answer(
        "💳 <b>Выбери пакет кредитов:</b>\n\n"
        "🎁 <b>Пробный</b> — 3 ТЗ за 79₽\n"
        "🔹 <b>Старт</b> — 5 ТЗ за 129₽\n"
        "📦 <b>Базовый</b> — 10 ТЗ за 229₽\n"
        "⭐ <b>Оптимальный</b> — 25 ТЗ за 449₽ 🔥\n"
        "🚀 <b>Профи</b> — 50 ТЗ за 749₽\n"
        "💼 <b>Бизнес</b> — 100 ТЗ за 1 290₽ 💎\n"
        "🏢 <b>Корпоративный</b> — 250 ТЗ за 2 790₽\n\n"
        "👑 <b>БЕЗЛИМИТ</b> — 1 790₽/месяц\n\n"
        "Выбери подходящий пакет:",
        reply_markup=get_packages_keyboard(),
    )


@router.message(Command("history"))
async def cmd_history(message: Message, user: User) -> None:
    """Команда /history - история генераций."""
    telegram_id = message.from_user.id if message.from_user else 0
    generations = await get_user_generations(telegram_id, limit=10)
    
    if not generations:
        await message.answer(
            "📋 <b>История генераций</b>\n\n"
            "У тебя пока нет созданных ТЗ.\n"
            "Нажми «🚀 Создать ТЗ» или /create чтобы начать!",
            reply_markup=get_main_menu_keyboard(),
        )
        return
    
    text = "📋 <b>Последние генерации:</b>\n\n"
    
    for gen in generations:
        date_str = gen.created_at.strftime("%d.%m.%Y %H:%M")
        category_emoji = {
            "clothes": "👕",
            "electronics": "📱",
            "cosmetics": "💄",
            "home": "🏠",
            "kids": "👶",
            "sports": "⚽",
            "other": "📦",
        }.get(gen.category, "📦")
        
        quality = gen.quality_score or 0
        text += f"{category_emoji} {date_str} — {quality}/100\n"
    
    await message.answer(text, reply_markup=get_main_menu_keyboard())


# ============================================================
# ОБРАБОТЧИКИ КНОПОК ГЛАВНОГО МЕНЮ
# ============================================================

@router.message(F.text.in_(["📸 Создать ТЗ", "🚀 Создать ТЗ"]))
async def btn_create_tz(
    message: Message,
    user: User,
    state: FSMContext,
) -> None:
    """
    Кнопка "Создать ТЗ".
    
    Проверяет баланс и переводит в режим ожидания фото.
    """
    # Проверяем баланс
    if user.balance <= 0 and not is_unlimited_active(user):
        await message.answer(
            "❌ <b>У тебя закончились кредиты!</b>\n\n"
            "Нажми «💰 Баланс» для пополнения.",
            reply_markup=get_main_menu_keyboard(),
        )
        return
    
    # Переводим в состояние ожидания фото
    await state.set_state(GenerationStates.waiting_photo)
    await state.update_data(photos=[])
    
    await message.answer(
        "📷 <b>Отправь фото товара</b>\n\n"
        "Можно отправить от 1 до 5 фотографий.\n"
        "Чем больше фото с разных ракурсов — тем лучше результат!\n\n"
        "💡 Совет: добавь фото упаковки и деталей товара",
    )
    
    logger.info(
        "User started generation",
        telegram_id=message.from_user.id,
        balance=user.balance,
    )


@router.message(F.text.in_(["💰 Баланс", " Баланс"]))
async def btn_balance(
    message: Message,
    user: User,
) -> None:
    """Кнопка "Баланс" - показывает баланс и статистику."""
    telegram_id = message.from_user.id if message.from_user else 0
    stats = await get_user_stats(telegram_id)
    
    # Формируем текст статуса
    if is_unlimited_active(user):
        status_text = "👑 Безлимит активен"
    elif user.balance > 5:
        status_text = "✅ Достаточно кредитов для работы"
    elif user.balance > 0:
        status_text = "⚠️ Кредиты заканчиваются"
    else:
        status_text = "❌ Кредиты закончились!"
    
    # Подсчитываем успешные генерации
    total = stats.get("generations_count", 0)
    
    await message.answer(
        BALANCE_MESSAGE.format(
            balance=get_balance_display(user),
            total_generations=total,
            successful=total,
            status_text=status_text,
        ),
        reply_markup=get_balance_keyboard(),
    )


@router.message(F.text.in_(["📋 История", "📋 Мои ТЗ", "� История"]))
async def btn_history(
    message: Message,
    user: User,
) -> None:
    """Кнопка "Мои ТЗ" - показывает последние генерации."""
    telegram_id = message.from_user.id if message.from_user else 0
    generations = await get_user_generations(telegram_id, limit=10)
    
    if not generations:
        await message.answer(
            "📋 <b>Мои ТЗ</b>\n\n"
            "У тебя пока нет созданных ТЗ.\n"
            "Нажми «🚀 Создать ТЗ», чтобы начать!",
            reply_markup=get_history_keyboard(),
        )
        return
    
    # Формируем список генераций
    lines = [
        "📋 <b>Мои последние ТЗ:</b>\n",
        "Нажми на ТЗ, чтобы скачать или посмотреть подробности:\n",
    ]
    
    for i, gen in enumerate(generations[:5], 1):
        category = gen.category or "Без категории"
        date_str = gen.created_at.strftime("%d.%m %H:%M")
        lines.append(f"{i}. ✅ {date_str} — {category}")
    
    if len(generations) > 5:
        lines.append(f"\n<i>Показаны последние 5 из {len(generations)} ТЗ</i>")
    
    await message.answer(
        "\n".join(lines),
        reply_markup=get_history_keyboard(generations),
    )


@router.message(F.text == "📖 Меню")
async def btn_menu(message: Message, user: User) -> None:
    """Кнопка "Меню" - показывает главное меню с описанием функций."""
    from bot.keyboards import get_main_menu_keyboard
    
    await message.answer(
        MENU_MESSAGE,
        reply_markup=get_main_menu_keyboard(),
    )


@router.message(F.text == "📝 Примеры")
async def btn_examples(message: Message, user: User) -> None:
    """Кнопка "Примеры" - показывает примеры готовых ТЗ."""
    from bot.keyboards import get_examples_keyboard
    
    await message.answer(
        EXAMPLES_MESSAGE,
        reply_markup=get_examples_keyboard(),
    )


@router.message(F.text == "💳 Купить кредиты")
async def btn_buy_credits(message: Message) -> None:
    """Кнопка "Купить кредиты" - показывает пакеты."""
    from bot.keyboards import get_packages_keyboard

    await message.answer(
        "💳 <b>Выбери пакет кредитов:</b>\n\n"
        "🎁 <b>Пробный</b> — 3 ТЗ за 79₽\n"
        "🔹 <b>Старт</b> — 5 ТЗ за 129₽\n"
        "📦 <b>Базовый</b> — 10 ТЗ за 229₽\n"
        "⭐ <b>Оптимальный</b> — 25 ТЗ за 449₽ 🔥\n"
        "🚀 <b>Профи</b> — 50 ТЗ за 749₽\n\n"
        "Выбери подходящий пакет:",
        reply_markup=get_packages_keyboard(),
    )


# ============================================================
# CALLBACK ОБРАБОТЧИКИ ДЛЯ INLINE КНОПОК
# ============================================================

@router.callback_query(F.data == "start_generation")
async def callback_start_generation(
    callback: CallbackQuery,
    user: User,
    state: FSMContext,
) -> None:
    """Callback для кнопки 'Создать ТЗ'."""
    await callback.answer()
    
    # Проверяем баланс
    if user.balance <= 0 and not is_unlimited_active(user):
        await callback.message.edit_text(
            "❌ <b>У тебя закончились кредиты!</b>\n\n"
            "Нажми «💰 Баланс» для пополнения.",
        )
        return
    
    # Переводим в состояние ожидания фото
    await state.set_state(GenerationStates.waiting_photo)
    await state.update_data(photos=[])
    
    await callback.message.edit_text(
        "📷 <b>Отправь фото товара</b>\n\n"
        "Можно отправить от 1 до 5 фотографий.\n"
        "Чем больше фото с разных ракурсов — тем лучше результат!\n\n"
        "💡 Совет: добавь фото упаковки и деталей товара",
    )


@router.callback_query(F.data == "show_examples")
async def callback_show_examples(callback: CallbackQuery) -> None:
    """Callback для кнопки 'Примеры работ'."""
    from bot.keyboards import get_examples_keyboard
    
    await callback.answer()
    
    await callback.message.edit_text(
        EXAMPLES_MESSAGE,
        reply_markup=get_examples_keyboard(),
    )


@router.callback_query(F.data.startswith("example:"))
async def callback_show_example_category(callback: CallbackQuery) -> None:
    """Callback для просмотра примера по категории."""
    from bot.keyboards import get_example_detail_keyboard
    
    await callback.answer()
    
    if not callback.data:
        return
    
    category = callback.data.split(":")[1]
    
    # Получаем пример для категории
    example_text = EXAMPLES_BY_CATEGORY.get(category)
    
    if not example_text:
        await callback.answer("Пример не найден", show_alert=True)
        return
    
    await callback.message.edit_text(
        example_text,
        reply_markup=get_example_detail_keyboard(category),
    )



@router.callback_query(F.data == "show_main_menu")
async def callback_show_main_menu(callback: CallbackQuery, user: User) -> None:
    """Callback для кнопки 'В главное меню'."""
    from bot.keyboards import get_main_menu_keyboard
    
    await callback.answer()
    
    await callback.message.edit_text(
        MENU_MESSAGE,
        reply_markup=get_main_menu_keyboard(),
    )


@router.callback_query(F.data == "show_balance")
async def callback_show_balance(callback: CallbackQuery, user: User) -> None:
    """Callback для кнопки 'Баланс' — профессиональный экран баланса."""
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    
    await callback.answer()
    
    telegram_id = callback.from_user.id if callback.from_user else 0
    stats = await get_user_stats(telegram_id)
    
    # Определяем эмодзи и статус баланса
    if is_unlimited_active(user):
        balance_emoji = "👑"
        status_text = "Безлимит активен"
    elif user.balance >= 10:
        balance_emoji = "🟢"
        status_text = "✅ Достаточно кредитов для работы"
    elif user.balance > 0:
        balance_emoji = "🟡"
        status_text = "⚠️ Кредиты заканчиваются — пополните баланс"
    else:
        balance_emoji = "🔴"
        status_text = "❌ Кредиты закончились!"
    
    # Подсчитываем генерации
    total = stats.get("generations_count", 0)
    
    # Формируем профессиональное сообщение о балансе
    text = (
        f"💰 <b>Ваш баланс</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n\n"
        f"{balance_emoji} <b>{get_balance_display(user)} кредитов</b>\n\n"
        f"📊 <b>Статистика:</b>\n"
        f"   • Сгенерировано ТЗ: {total}\n"
        f"   • Дата регистрации: {user.created_at.strftime('%d.%m.%Y')}\n\n"
        f"{status_text}\n\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n"
    )
    
    # Показываем выгодные тарифы
    if user.balance < 5:
        text += (
            f"\n🔥 <b>Рекомендуем:</b>\n"
            f"   ⭐ Оптимальный — 25 ТЗ за 449₽ (экономия 40%)\n"
            f"   👑 Безлимит — 1 790₽/месяц без ограничений\n"
        )
    
    # Создаём клавиатуру
    builder = InlineKeyboardBuilder()
    builder.button(text="💳 Пополнить баланс", callback_data="show_packages")
    builder.button(text="📖 В главное меню", callback_data="show_main_menu")
    builder.adjust(1)
    
    if callback.message:
        await callback.message.edit_text(
            text=text,
            reply_markup=builder.as_markup(),
            parse_mode="HTML",
        )


@router.callback_query(F.data == "show_history")
async def callback_show_history(callback: CallbackQuery, user: User) -> None:
    """Callback для кнопки 'Мои ТЗ'."""
    await callback.answer()
    
    telegram_id = callback.from_user.id if callback.from_user else 0
    generations = await get_user_generations(telegram_id, limit=10)
    
    if not generations:
        await callback.message.edit_text(
            "📋 <b>Мои ТЗ</b>\n\n"
            "У тебя пока нет созданных ТЗ.\n"
            "Нажми «🚀 Создать ТЗ», чтобы начать!",
            reply_markup=get_history_keyboard(),
        )
        return
    
    # Формируем список генераций
    lines = [
        "📋 <b>Мои последние ТЗ:</b>\n",
        "Нажми на ТЗ, чтобы скачать или посмотреть подробности:\n",
    ]
    
    for i, gen in enumerate(generations[:5], 1):
        category = gen.category or "Без категории"
        date_str = gen.created_at.strftime("%d.%m %H:%M")
        lines.append(f"{i}. ✅ {date_str} — {category}")
    
    if len(generations) > 5:
        lines.append(f"\n<i>Показаны последние 5 из {len(generations)} ТЗ</i>")
    
    await callback.message.edit_text(
        "\n".join(lines),
        reply_markup=get_history_keyboard(generations),
    )


@router.callback_query(F.data.startswith("view_tz:"))
async def callback_view_tz(callback: CallbackQuery, user: User) -> None:
    """Callback для просмотра конкретного ТЗ."""
    await callback.answer()
    
    if not callback.data:
        return
    
    generation_id = int(callback.data.split(":")[1])
    generation = await get_generation_by_id(generation_id)
    
    if not generation:
        await callback.message.edit_text(
            "❌ ТЗ не найдено",
            reply_markup=get_history_keyboard(),
        )
        return
    
    category = generation.category or "Без категории"
    date_str = generation.created_at.strftime("%d.%m.%Y %H:%M")
    
    # Формируем сообщение с информацией о ТЗ
    text = (
        f"📄 <b>Техническое задание #{generation.id}</b>\n\n"
        f"📁 <b>Категория:</b> {category}\n"
        f"📅 <b>Дата создания:</b> {date_str}\n"
    )
    
    if generation.quality_score:
        text += f"⭐ <b>Оценка качества:</b> {generation.quality_score}/100\n"
    
    # Добавляем краткую выдержку из ТЗ (первые 500 символов)
    if generation.tz_text:
        preview = generation.tz_text[:500]
        if len(generation.tz_text) > 500:
            preview += "..."
        text += f"\n<b>Превью:</b>\n<code>{preview}</code>\n"
    
    text += (
        "\n💡 <i>Нажми «Скачать PDF» для полной версии</i>\n\n"
        "────────────────────\n"
        "🎁 <b>Предложи идею</b> — за оригинальную идею\n"
        "или клёвую правку дам <b>+2 лимита</b> в знак благодарности!"
    )
    
    await callback.message.edit_text(
        text,
        reply_markup=get_tz_detail_keyboard(generation_id),
    )


@router.callback_query(F.data == "suggest_idea")
async def callback_suggest_idea(callback: CallbackQuery) -> None:
    """Callback для кнопки 'Предложить идею'."""
    from bot.config import settings
    
    await callback.answer()
    
    # Получаем username админа из конфига
    admin_contact = f"@{settings.admin_username}" if hasattr(settings, 'admin_username') and settings.admin_username else "администратору"
    
    # Создаем клавиатуру с inline кнопкой
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="📝 Отправить идею", callback_data="send_idea"))
    builder.row(InlineKeyboardButton(text="◀️ Назад", callback_data="show_history"))
    
    await callback.message.edit_text(
        "💡 <b>Предложить идею</b>\n\n"
        "Есть классная идея или предложение по улучшению бота?\n"
        "Нашёл баг или хочешь предложить новую функцию?\n\n"
        f"📩 Напиши {admin_contact}\n\n"
        "🎁 <b>За оригинальную идею или клёвую правку</b>\n"
        "получишь <b>+2 бесплатных лимита</b> в знак благодарности!\n\n"
        "Примеры идей:\n"
        "• Новая категория товаров\n"
        "• Улучшение формата ТЗ\n"
        "• Новая полезная функция\n"
        "• Исправление ошибок",
        reply_markup=builder.as_markup(),
    )


@router.callback_query(F.data == "send_idea")
async def callback_send_idea(callback: CallbackQuery, state: FSMContext) -> None:
    """Начало процесса отправки идеи."""
    await callback.answer()
    
    # Создаем клавиатуру с кнопкой отмены
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="❌ Отмена", callback_data="cancel_idea"))
    
    await callback.message.edit_text(
        "📝 <b>Отправить идею</b>\n\n"
        "Опиши свою идею или предложение по улучшению бота.\n\n"
        "<i>Минимум 10 символов, максимум 1000.</i>\n\n"
        "Напиши своё сообщение:",
        reply_markup=builder.as_markup(),
    )
    
    # Устанавливаем состояние ожидания текста идеи
    await state.set_state(IdeaStates.waiting_idea_text)


@router.message(IdeaStates.waiting_idea_text, F.text)
async def handle_idea_text(message: Message, state: FSMContext, user: User) -> None:
    """Обработка текста идеи от пользователя."""
    from bot.config import settings
    
    idea_text = message.text.strip()
    
    # Валидация длины
    if len(idea_text) < 10:
        builder = InlineKeyboardBuilder()
        builder.row(InlineKeyboardButton(text="❌ Отмена", callback_data="cancel_idea"))
        
        await message.answer(
            "❌ Слишком короткое сообщение.\n\n"
            "Пожалуйста, опиши идею подробнее (минимум 10 символов).",
            reply_markup=builder.as_markup(),
        )
        return
    
    if len(idea_text) > 1000:
        builder = InlineKeyboardBuilder()
        builder.row(InlineKeyboardButton(text="❌ Отмена", callback_data="cancel_idea"))
        
        await message.answer(
            "❌ Слишком длинное сообщение.\n\n"
            "Пожалуйста, сократи текст (максимум 1000 символов).",
            reply_markup=builder.as_markup(),
        )
        return
    
    # Получаем информацию о пользователе
    user_stats = await get_user_stats(user.telegram_id)
    
    # Сохраняем идею в БД
    idea_record = None
    try:
        idea_record = await create_idea(user.id, idea_text)
    except Exception as e:
        logger.error("idea_save_failed", error=str(e), telegram_id=user.telegram_id)
    
    # Формируем сообщение для админов
    admin_message = (
        f"💡 <b>Новая идея от пользователя</b>\n\n"
        f"👤 <b>От:</b> {message.from_user.full_name}"
    )
    
    if message.from_user.username:
        admin_message += f" (@{message.from_user.username})"
    
    admin_message += (
        f"\n🆔 <b>ID:</b> <code>{user.telegram_id}</code>\n"
        f"💰 <b>Баланс:</b> {user.balance} генераций\n"
        f"📊 <b>Создано ТЗ:</b> {user_stats['total_generations']}\n"
        f"🧾 <b>ID идеи:</b> <code>{idea_record.id if idea_record else '—'}</code>\n\n"
        f"💬 <b>Текст идеи:</b>\n{idea_text}"
    )
    
    # Отправляем сообщение всем админам из настроек
    if settings.admin_ids:
        for admin_id in settings.admin_ids:
            try:
                await message.bot.send_message(
                    chat_id=admin_id,
                    text=admin_message,
                    parse_mode="HTML",
                )
            except Exception as e:
                logger.warning(
                    "Failed to send idea to admin",
                    admin_id=admin_id,
                    error=str(e),
                )
    else:
        logger.warning("No admin IDs configured for idea notifications")
    
    # Отправляем подтверждение пользователю
    from bot.keyboards import get_main_menu_keyboard
    
    await message.answer(
        "✅ <b>Спасибо за идею!</b>\n\n"
        "Твоё предложение отправлено модераторам.\n"
        "Мы обязательно рассмотрим его!\n\n"
        "🎁 За оригинальные идеи награждаем <b>+2 лимита</b>.",
        reply_markup=get_main_menu_keyboard(),
    )
    
    # Очищаем состояние
    await state.clear()
    
    logger.info(
        "User submitted idea",
        user_id=user.telegram_id,
        username=message.from_user.username if message.from_user else None,
        idea_length=len(idea_text),
    )


@router.callback_query(F.data == "cancel_idea")
async def callback_cancel_idea(callback: CallbackQuery, state: FSMContext, user: User) -> None:
    """Отмена отправки идеи."""
    from bot.keyboards import get_main_menu_keyboard
    
    await callback.answer()
    await state.clear()
    
    await callback.message.edit_text(
        "❌ Отправка идеи отменена.\n\n"
        "Ты можешь вернуться к этому позже!",
        reply_markup=get_main_menu_keyboard(),
    )


