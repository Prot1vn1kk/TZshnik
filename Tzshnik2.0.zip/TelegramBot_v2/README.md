# 🤖 ТЗшник v2.0

> Telegram-бот для автоматической генерации технических заданий (ТЗ) для инфографики товаров на маркетплейсах Wildberries и Ozon.

---

## 📋 Описание

**ТЗшник** — это AI-powered бот, который:

1. 📸 Принимает фото товара (1-5 шт.)
2. 🔍 Анализирует изображение с помощью Vision AI
3. ✍️ Генерирует структурированное ТЗ для дизайнера
4. 📄 Отдаёт результат в формате текст + PDF

---

## 🛠 Технологический стек

| Компонент | Технология |
|-----------|------------|
| Язык | Python 3.11+ |
| Bot Framework | aiogram 3.x |
| База данных | SQLite + aiosqlite |
| ORM | SQLAlchemy 2.0 (async) |
| AI Vision | GLM-4V (Z.ai) |
| AI Text | GLM-4 (Z.ai) |
| Fallback AI | Google Gemini Flash |
| Конфигурация | pydantic-settings |
| Логирование | structlog |
| Платежи | YooKassa (Telegram Payments) |
| PDF | fpdf2 |

---

## 🚀 Быстрый старт

### 1. Клонирование и установка

```bash
# Клонируй репозиторий
git clone <repo_url>
cd TelegramBot_v2

# Создай виртуальное окружение
python -m venv venv

# Активируй (Windows)
venv\Scripts\activate

# Активируй (Linux/macOS)
source venv/bin/activate

# Установи зависимости
pip install -r requirements.txt
```

### 2. Конфигурация

```bash
# Скопируй пример конфигурации
cp .env.example .env

# Отредактируй .env и заполни свои значения:
# - TELEGRAM_BOT_TOKEN - токен от @BotFather
# - ADMIN_USER_ID - твой Telegram ID
# - GLM_API_KEY - ключ от Z.ai
# - GEMINI_API_KEY - ключ от Google AI Studio
```

### 3. Запуск

```bash
# Запуск бота
python bot/main.py
```

---

## 📁 Структура проекта

```
TelegramBot_v2/
├── bot/                    # Telegram бот
│   ├── handlers/           # Обработчики команд
│   ├── config.py           # Конфигурация
│   ├── keyboards.py        # Клавиатуры
│   └── main.py             # Точка входа
├── core/                   # Бизнес-логика
│   ├── ai_providers/       # GLM, Gemini провайдеры
│   ├── generator.py        # Генерация ТЗ
│   ├── validator.py        # Валидация качества
│   ├── prompts.py          # Промпты для AI
│   ├── pdf_export.py       # PDF экспорт
│   └── exceptions.py       # Исключения
├── database/               # База данных
│   ├── models.py           # SQLAlchemy модели
│   ├── crud.py             # CRUD операции
│   └── database.py         # Подключение
├── utils/                  # Утилиты
│   ├── progress.py         # Прогресс-бар
│   └── helpers.py          # Вспомогательные функции
├── data/                   # SQLite база (создаётся автоматически)
├── exports/                # PDF файлы
├── docs/                   # Документация
├── .env                    # Секреты (не в git!)
├── .env.example            # Пример .env
├── requirements.txt        # Зависимости
└── README.md               # Этот файл
```

---

## 💰 Монетизация

| Пакет | ТЗ | Цена |
|-------|-----|------|
| Бесплатно | 1 | 0₽ |
| Старт | 5 | 149₽ |
| Оптимальный | 20 | 399₽ |
| Профи | 50 | 699₽ |
| Безлимит | ∞/мес | 1499₽ |

---

## 📚 Документация

Подробная документация находится в папке `docs/`:

- [00_PROJECT_OVERVIEW.md](docs/00_PROJECT_OVERVIEW.md) — Обзор проекта
- [01_RULES_FOR_AI.md](docs/01_RULES_FOR_AI.md) — Правила кодирования
- [02_DATABASE_SCHEMA.md](docs/02_DATABASE_SCHEMA.md) — Схема БД
- [03_AI_PROVIDERS.md](docs/03_AI_PROVIDERS.md) — AI провайдеры
- [04_PROMPTS.md](docs/04_PROMPTS.md) — Промпты для AI

---

## 🧪 Тестирование

```bash
# Запуск тестов
pytest

# С покрытием
pytest --cov=bot --cov=core --cov=database
```

---

## 📝 Лицензия

Все права защищены © 2026

---

## 👤 Автор

Разработано с помощью AI 🤖
