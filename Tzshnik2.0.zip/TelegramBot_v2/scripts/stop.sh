#!/bin/bash
# ==============================================
# ТЗшник v2.0 - Скрипт остановки бота
# ==============================================

echo "🛑 Остановка бота..."

# Находим PID процесса
PID=$(pgrep -f "python -m bot" || pgrep -f "python3 -m bot")

if [ -z "$PID" ]; then
    echo "⚠️ Бот не запущен"
    exit 0
fi

echo "📍 Найден процесс: $PID"

# Отправляем SIGTERM для graceful shutdown
kill -SIGTERM "$PID" 2>/dev/null

# Ждём завершения (максимум 10 секунд)
for i in {1..10}; do
    if ! ps -p "$PID" > /dev/null 2>&1; then
        echo "✅ Бот остановлен"
        exit 0
    fi
    sleep 1
done

# Если не завершился - принудительно
echo "⚠️ Принудительная остановка..."
kill -SIGKILL "$PID" 2>/dev/null
echo "✅ Бот остановлен принудительно"
