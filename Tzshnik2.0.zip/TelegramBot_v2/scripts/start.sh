#!/bin/bash
# ==============================================
# ТЗшник v2.0 - Скрипт запуска бота
# Для VPS серверов (Linux)
# ==============================================

# Переход в директорию проекта
cd "$(dirname "$0")/.." || exit 1

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}🤖 ТЗшник v2.0 - Запуск${NC}"
echo "================================"

# Проверка наличия .env файла
if [ ! -f ".env" ]; then
    echo -e "${RED}❌ Файл .env не найден!${NC}"
    echo "Скопируйте .env.example в .env и заполните настройки:"
    echo "  cp .env.example .env"
    echo "  nano .env"
    exit 1
fi

# Проверка наличия виртуального окружения
if [ ! -d "venv" ]; then
    echo -e "${YELLOW}⚠️ Виртуальное окружение не найдено. Создаю...${NC}"
    python3 -m venv venv
fi

# Активация виртуального окружения
echo "📦 Активация виртуального окружения..."
source venv/bin/activate

# Проверка установки зависимостей
if ! python -c "import aiogram" 2>/dev/null; then
    echo -e "${YELLOW}⚠️ Зависимости не установлены. Устанавливаю...${NC}"
    pip install --upgrade pip
    pip install -r requirements.txt
fi

# Создание необходимых директорий
mkdir -p data exports logs

# Запуск бота
echo -e "${GREEN}🚀 Запуск бота...${NC}"
echo "================================"

# Запуск с автоматическим рестартом при падении
while true; do
    python -m bot
    
    EXIT_CODE=$?
    
    if [ $EXIT_CODE -eq 0 ]; then
        echo -e "${GREEN}✅ Бот остановлен корректно${NC}"
        break
    else
        echo -e "${RED}❌ Бот упал с кодом $EXIT_CODE. Перезапуск через 5 секунд...${NC}"
        sleep 5
    fi
done
